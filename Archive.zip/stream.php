<section class="mbr-section mbr-section--relative mbr-section--fixed-size" id="msg-box3-48" style="">
    
    
    
    
</section>

<section class="mbr-gallery mbr-section mbr-section--no-padding mbr-parallax-background"  style="background-image: url(assets/images/bglive.jpg);">
    <!-- Gallery -->
    <div class="mbr-section__container container mbr-section__container--isolated">
        <div class="mbr-header mbr-header--wysiwyg row" style="background-color: rgba(255, 255, 255, 0.64);">
            <center>
            <div class="col-sm-12 ">
                <h3 class="mbr-header__text wow zoomInRight" data-wow-duration="1000ms" data-wow-delay="100ms" style="font-family: 'Reem Kufi', sans-serif;">Live Streaming</h3>
            </div>
            </center>
        </div>
    </div>
    <div class=" mbr-gallery-layout-default">
        <div>
            <div class="row mbr-gallery-row no-gutter">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 col-md-offset-3 col-sm-offset-3 mbr-gallery-item wow zoomIn" data-wow-duration="1000ms" data-wow-delay="300ms" style="color: rgb(255, 255, 255);background: rgba(74, 71, 77, 0.89);">
                    <div class="embed-responsive embed-responsive-4by3" style="-webkit-box-shadow: 0px 0px 43px 2px rgba(0,0,0,0.75);-moz-box-shadow: 0px 0px 43px 2px rgba(0,0,0,0.75);box-shadow: 0px 0px 43px 2px rgba(0,0,0,0.75);">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/3LqlO5bUIZ4" frameborder="0" allowfullscreen></iframe>
                    </div>
                    <div>
                      <h4>Live Stream Hijab Hunt 2017</h4>
                      
                      <div class="multiply"></div>
                    </div>
                </div>
                
            </div>
            <div style="height:150px;"></div>
        </div>
        <div class="clearfix"></div>
    </div>

    <!-- Lightbox -->
    
</section>