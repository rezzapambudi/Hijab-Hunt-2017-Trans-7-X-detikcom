<section class="mbr-section mbr-section--relative mbr-section--fixed-size" id="msg-box3-48" style="background-color: whitesmoke;">
    
    <div class="mbr-section__container container mbr-section__container--isolated">
        <div class="mbr-header mbr-header--wysiwyg row">
            <div class="col-sm-8 col-sm-offset-2">
                <h3 class="mbr-header__text wow zoomInRight" data-wow-duration="1000ms" data-wow-delay="100ms" style="font-family: 'Reem Kufi', sans-serif;">VIDEOS</h3>
                
            </div>
        </div>
    </div>
    
    
</section>

<section class="mbr-gallery mbr-section mbr-section--no-padding"  style="background-color: rgb(239, 239, 239);">
    <!-- Gallery -->
    
    <div class=" mbr-gallery-layout-default">
        <div>
            <div class="row mbr-gallery-row no-gutter">
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 mbr-gallery-item wow zoomIn" data-wow-duration="1000ms" data-wow-delay="300ms" style="color: rgb(255, 255, 255);background: rgb(74, 71, 77);">
                    <div class="embed-responsive embed-responsive-4by3">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/XMYMtLAH-7c" frameborder="0" allowfullscreen></iframe>
                    </div>
                    <div>
                      <h4>Simple Hijab Tutorial</h4>
                      
                      <div class="multiply"></div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 mbr-gallery-item wow zoomIn" data-wow-duration="1000ms" data-wow-delay="300ms" style="color: rgb(255, 255, 255);background:rgb(66, 76, 113);">
                    <div class="embed-responsive embed-responsive-4by3">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/XMYMtLAH-7c" frameborder="0" allowfullscreen></iframe>
                    </div>
                    <div>
                      <h4>Simple Hijab Tutorial</h4>
                      
                      <div class="multiply"></div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 mbr-gallery-item wow zoomIn" data-wow-duration="1000ms" data-wow-delay="300ms" style="color: rgb(255, 255, 255);background: rgb(74, 71, 77);">
                    <div class="embed-responsive embed-responsive-4by3">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/XMYMtLAH-7c" frameborder="0" allowfullscreen></iframe>
                    </div>
                    <div>
                      <h4>Simple Hijab Tutorial</h4>
                      
                      <div class="multiply"></div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 mbr-gallery-item wow zoomIn" data-wow-duration="1000ms" data-wow-delay="300ms" style="color: rgb(255, 255, 255);background:rgb(66, 76, 113);">
                    <div class="embed-responsive embed-responsive-4by3">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/XMYMtLAH-7c" frameborder="0" allowfullscreen></iframe>
                    </div>
                    <div>
                      <h4>Simple Hijab Tutorial</h4>
                      
                      <div class="multiply"></div>
                    </div>
                </div>
            </div>
            <div class="row mbr-gallery-row no-gutter">
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 mbr-gallery-item wow zoomIn" data-wow-duration="1000ms" data-wow-delay="300ms" style="color: rgb(255, 255, 255);background: rgb(74, 71, 77);">
                    <div class="embed-responsive embed-responsive-4by3">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/XMYMtLAH-7c" frameborder="0" allowfullscreen></iframe>
                    </div>
                    <div>
                      <h4>Simple Hijab Tutorial</h4>
                      
                      <div class="multiply"></div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 mbr-gallery-item wow zoomIn" data-wow-duration="1000ms" data-wow-delay="300ms" style="color: rgb(255, 255, 255);background:rgb(66, 76, 113);">
                    <div class="embed-responsive embed-responsive-4by3">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/XMYMtLAH-7c" frameborder="0" allowfullscreen></iframe>
                    </div>
                    <div>
                      <h4>Simple Hijab Tutorial</h4>
                      
                      <div class="multiply"></div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 mbr-gallery-item wow zoomIn" data-wow-duration="1000ms" data-wow-delay="300ms" style="color: rgb(255, 255, 255);background: rgb(74, 71, 77);">
                    <div class="embed-responsive embed-responsive-4by3">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/XMYMtLAH-7c" frameborder="0" allowfullscreen></iframe>
                    </div>
                    <div>
                      <h4>Simple Hijab Tutorial</h4>
                      
                      <div class="multiply"></div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 mbr-gallery-item wow zoomIn" data-wow-duration="1000ms" data-wow-delay="300ms" style="color: rgb(255, 255, 255);background:rgb(66, 76, 113);">
                    <div class="embed-responsive embed-responsive-4by3">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/XMYMtLAH-7c" frameborder="0" allowfullscreen></iframe>
                    </div>
                    <div>
                      <h4>Simple Hijab Tutorial</h4>
                      
                      <div class="multiply"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>

    <!-- Lightbox -->
    
</section>