<section class="content-2 col-4 mbr-parallax-background" id="features1-42" style="background-image: url(assets/images/iphone-6-458150-1920-1920x1285-73.jpg);padding-bottom:20px;">
    <div class="container">
        <center><h3 class="mbr-header__text wow lightSpeedIn" style="padding-bottom: 30px;color: rgb(217, 62, 45);">NEWS</h3></center>
        <div class="row">
            <div class="boxarticle">
                <div class="thumbnail thumb-shadow">
                    <div class="image"><img class="undefined" src="" style="width: 400px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                    <div class="caption">
                        <div>
                            <a href="#"><h3 class="judul">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h3></a>
                            <p class="artikel">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita. Lorem ipsum dolor sit amet, consectetur adipiscing elit.&nbsp;</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="boxarticle">
                <div class="thumbnail thumb-shadow">
                    <div class="image"><img class="undefined" src="" style="width: 400px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel4.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                    <div class="caption">
                        <div>
                            <a href="#"><h3 class="judul">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h3></a>
                            <p class="artikel">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita. Lorem ipsum dolor sit amet, consectetur adipiscing elit.&nbsp;</p>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="boxarticle">
                <div class="thumbnail thumb-shadow">
                    <div class="image"><img class="undefined" src="" style="width: 400px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                    <div class="caption">
                        <div>
                            <a href="#"><h3 class="judul">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h3></a>
                            <p class="artikel">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita. Lorem ipsum dolor sit amet, consectetur adipiscing elit.&nbsp;</p>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="boxarticle">
                <div class="thumbnail thumb-shadow">
                    <div class="image"><img class="undefined" src="" style="width: 400px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel4.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                    <div class="caption">
                        <div>
                            <a href="#"><h3 class="judul">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h3></a>
                            <p class="artikel">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita. Lorem ipsum dolor sit amet, consectetur adipiscing elit.&nbsp;</p>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="boxarticle">
                <div class="thumbnail thumb-shadow">
                    <div class="image"><img class="undefined" src="" style="width: 400px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                    <div class="caption">
                        <div>
                            <a href="#"><h3 class="judul">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h3></a>
                            <p class="artikel">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita. Lorem ipsum dolor sit amet, consectetur adipiscing elit.&nbsp;</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="boxarticle">
                <div class="thumbnail thumb-shadow">
                    <div class="image"><img class="undefined" src="" style="width: 400px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel4.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                    <div class="caption">
                        <div>
                            <a href="#"><h3 class="judul">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h3></a>
                            <p class="artikel">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita. Lorem ipsum dolor sit amet, consectetur adipiscing elit.&nbsp;</p>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="boxarticle">
                <div class="thumbnail thumb-shadow">
                    <div class="image"><img class="undefined" src="" style="width: 400px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                    <div class="caption">
                        <div>
                            <a href="#"><h3 class="judul">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h3></a>
                            <p class="artikel">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita. Lorem ipsum dolor sit amet, consectetur adipiscing elit.&nbsp;</p>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="boxarticle">
                <div class="thumbnail thumb-shadow">
                    <div class="image"><img class="undefined" src="" style="width: 400px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel4.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                    <div class="caption">
                        <div>
                            <a href="#"><h3 class="judul">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h3></a>
                            <p class="artikel">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita. Lorem ipsum dolor sit amet, consectetur adipiscing elit.&nbsp;</p>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--<center>
<section class="content-1 col-1 wow zoomIn" id="features1-42" style="background-color: rgb(255, 255, 255);padding-bottom:30px;">
    <a href="detail.php"><img src="assets/images/load-more.gif"></a>
</section>
</center>-->