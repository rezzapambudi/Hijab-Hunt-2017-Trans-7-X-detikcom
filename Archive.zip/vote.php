<section class="mbr-section mbr-section--relative mbr-section--fixed-size mbr-parallax-background" id="msg-box3-48" style="background-image: url(assets/images/bgvote.jpg);background-color: rgba(0, 0, 0, 0.68);">
    <div class="container">
	<div class="row" style="padding-top: 100px;">
		                                <div class="col-md-12">
                                    <!-- Nav tabs --><div class="card">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Semua Peserta</a></li>
                                        <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Audisi Kota</a></li>
                                        <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">15 Finalis</a></li>
                                        <li role="presentation"><a href="#settings" aria-controls="settings" role="tab" data-toggle="tab">8 Besar</a></li>
                                    </ul>

                                    <!-- Tab panes -->
                                    <div class="tab-content">
                                        <div role="tabpanel" class="tab-pane active" id="home">
                                        <?php include "vote1.php";?>
                                    </div>
                                        <div role="tabpanel" class="tab-pane" id="profile">
                                        <?php include "vote2.php";?>
                                    </div>
                                        <div role="tabpanel" class="tab-pane" id="messages">
                                        <?php include "vote3.php";?>
                                    </div>
                                        <div role="tabpanel" class="tab-pane" id="settings">
                                        <?php include "vote4.php";?>
                                    </div>
                                    </div>
</div>
                                </div>
	</div>
</div>
    
</section>