<footer class="mbr-section mbr-section--relative mbr-section--fixed-size" id="footer1-58" style="background-color: rgb(68, 68, 68);">
    
    <div class="mbr-section__container container">
        <div class="mbr-footer mbr-footer--wysiwyg row">
            <div class="col-sm-12">
                <p class="mbr-footer__copyright"></p><p>Copyright (c) 2016 Detikcom.</p><p></p>
            </div>
        </div>
    </div>
</footer>
