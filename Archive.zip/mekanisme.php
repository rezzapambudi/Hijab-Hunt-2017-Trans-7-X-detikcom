<!--
<ul class="nav nav-tabs md-pills pills-default" role="tablist">
    <li class="nav-item">
        <a class="nav-link active" data-toggle="tab" href="#panel31" role="tab"><img src="assets/images/icon/register.png" class="img-responsive" style="max-width:70px;"><br> Profile</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#panel32" role="tab"><img src="assets/images/icon/audisi.png" class="img-responsive" style="max-width:70px;"><br> Follow</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#panel33" role="tab"><img src="assets/images/icon/home.png" class="img-responsive" style="max-width:70px;"><br> Contact</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#panel33" role="tab"><img src="assets/images/icon/live.png" class="img-responsive" style="max-width:70px;"><br> Contact</a>
    </li>
</ul>
-->

<!--<div class="container">
    <div class="row">
    	<section>
        <div class="wizard">
            <div class="wizard-inner">
                <div class="connecting-line"></div>
                <ul class="nav nav-tabs" role="tablist">

                    <li role="presentation" class="active">
                        <a href="#step1" data-toggle="tab" aria-controls="step1" role="tab" title="Step 1">
                            <span class="round-tab">
                                <img src="assets/images/icon/register.png" class="img-responsive">
                            </span>
                        </a>
                    </li>

                    <li role="presentation" class="disabled">
                        <a href="#step2" data-toggle="tab" aria-controls="step2" role="tab" title="Step 2">
                            <span class="round-tab">
                                <img src="assets/images/icon/audisi.png" class="img-responsive">
                            </span>
                        </a>
                    </li>
                    <li role="presentation" class="disabled">
                        <a href="#step3" data-toggle="tab" aria-controls="step3" role="tab" title="Step 3">
                            <span class="round-tab">
                                <img src="assets/images/icon/home.png" class="img-responsive" style="border-radius: 50%;">
                            </span>
                        </a>
                    </li>

                    <li role="presentation" class="disabled">
                        <a href="#complete" data-toggle="tab" aria-controls="complete" role="tab" title="Complete">
                            <span class="round-tab">
                                <img src="assets/images/icon/live.png" class="img-responsive" style="border-radius: 50%;">
                            </span>
                        </a>
                    </li>
                </ul>
            </div>

            
        </div>
        <div class="clearfix"></div>
    </section>
   </div>
</div>-->

<div class="container">
    <div class="row">
    	<section>
        <div class="parent2">
          <div class="test1"><i class="fa fa-user fa-2x"></i></div>
          <div class="test2"><i class="fa fa-graduation-cap fa-2x"></i></div>
          <div class="test3"><i class="fa fa-code fa-2x"></i></div>
          <div class="test4"><i class="fa fa-envelope-o fa-2x"></i></div>
          <div class="mask2"><i class="fa fa-home fa-3x"></i></div>
        </div>
        <div class="clearfix"></div>
    </section>
   </div>
</div>