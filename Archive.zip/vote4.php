<div class="mbr-section__container container mbr-section__container--isolated">
                                            <div class="mbr-header mbr-header--wysiwyg row">
                                                <div class="col-sm-8 col-sm-offset-2">
                                                    <h2 class="mbr-header__text wow zoomInRight" data-wow-duration="1000ms" data-wow-delay="100ms" style="font-family: 'Reem Kufi', sans-serif;color: #ffffff;">Peserta Hijab Hunt 2017</h2>

                                                </div>
                                            </div>
                                        </div>

                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-md-offset-1">
                                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 bckontestan">
                                            <div class="media">
                                                <a class="pull-left" href="#">
                                                    <img class="media-object dp img-circle fotokontestan" src="assets/images/kontestan/a.jpg">
                                                </a>
                                                <div class="media-body ketkontestan">
                                                    <h4 class="media-heading">Nisa Sabrina <br><small> Jakarta</small></h4>
                                                    <h5>Kirim SMS ke 9345 kode sms: HIJAB[spasi]01</h5>
                                                    <hr style="margin:8px auto">


                                                    <a href="#"><img src="assets/images/icon/fb_round.png" alt=""></a>
                                                    <a href="#"><img src="assets/images/icon/twitter_round.png" alt=""></a>
                                                    <a href="#"><img src="assets/images/icon/yt_round2.png" alt=""></a>


                                                </div>
                                            </div>

                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 bckontestan">
                                            <div class="media">
                                                <a class="pull-left" href="#">
                                                    <img class="media-object dp img-circle fotokontestan" src="assets/images/kontestan/c.jpg">
                                                </a>
                                                <div class="media-body ketkontestan">
                                                    <h4 class="media-heading">Rizki Desy Wulansari <br><small> Jakarta</small></h4>
                                                    <h5>Kirim SMS ke 9345 kode sms: HIJAB[spasi]01</h5>
                                                    <hr style="margin:8px auto">

                                                    <a href="#"><img src="assets/images/icon/fb_round.png" alt=""></a>
                                                    <a href="#"><img src="assets/images/icon/twitter_round.png" alt=""></a>
                                                    <a href="#"><img src="assets/images/icon/yt_round2.png" alt=""></a>

                                                </div>
                                            </div>

                                        </div>
                                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 bckontestan">
                                            <div class="media">
                                                <a class="pull-left" href="#">
                                                    <img class="media-object dp img-circle fotokontestan" src="assets/images/kontestan/d.jpg">
                                                </a>
                                                <div class="media-body ketkontestan">
                                                    <h4 class="media-heading">Nisa Sabrina <br><small> Jakarta</small></h4>
                                                    <h5>Kirim SMS ke 9345 kode sms: HIJAB[spasi]01</h5>
                                                    <hr style="margin:8px auto">

                                                    <a href="#"><img src="assets/images/icon/fb_round.png" alt=""></a>
                                                    <a href="#"><img src="assets/images/icon/twitter_round.png" alt=""></a>
                                                    <a href="#"><img src="assets/images/icon/yt_round2.png" alt=""></a>

                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                    </div>
                                    <div class="row" style="margin-top: 10px;">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-md-offset-1">
                                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 bckontestan">
                                            <div class="media">
                                                <a class="pull-left" href="#">
                                                    <img class="media-object dp img-circle fotokontestan" src="assets/images/kontestan/a.jpg">
                                                </a>
                                                <div class="media-body ketkontestan">
                                                    <h4 class="media-heading">Nisa Sabrina <br><small> Jakarta</small></h4>
                                                    <h5>Kirim SMS ke 9345 kode sms: HIJAB[spasi]01</h5>
                                                    <hr style="margin:8px auto">

                                                    <a href="#"><img src="assets/images/icon/fb_round.png" alt=""></a>
                                                    <a href="#"><img src="assets/images/icon/twitter_round.png" alt=""></a>
                                                    <a href="#"><img src="assets/images/icon/yt_round2.png" alt=""></a>

                                                </div>
                                            </div>

                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 bckontestan">
                                            <div class="media">
                                                <a class="pull-left" href="#">
                                                    <img class="media-object dp img-circle fotokontestan" src="assets/images/kontestan/c.jpg">
                                                </a>
                                                <div class="media-body ketkontestan">
                                                    <h4 class="media-heading">Rizki Desy Wulansari <br><small> Jakarta</small></h4>
                                                    <h5>Kirim SMS ke 9345 kode sms: HIJAB[spasi]01</h5>
                                                    <hr style="margin:8px auto">

                                                    <a href="#"><img src="assets/images/icon/fb_round.png" alt=""></a>
                                                    <a href="#"><img src="assets/images/icon/twitter_round.png" alt=""></a>
                                                    <a href="#"><img src="assets/images/icon/yt_round2.png" alt=""></a>

                                                </div>
                                            </div>

                                        </div>
                                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 bckontestan">
                                            <div class="media">
                                                <a class="pull-left" href="#">
                                                    <img class="media-object dp img-circle fotokontestan" src="assets/images/kontestan/d.jpg">
                                                </a>
                                                <div class="media-body ketkontestan">
                                                    <h4 class="media-heading">Nisa Sabrina <br><small> Jakarta</small></h4>
                                                    <h5>Kirim SMS ke 9345 kode sms: HIJAB[spasi]01</h5>
                                                    <hr style="margin:8px auto">

                                                    <a href="#"><img src="assets/images/icon/fb_round.png" alt=""></a>
                                                    <a href="#"><img src="assets/images/icon/twitter_round.png" alt=""></a>
                                                    <a href="#"><img src="assets/images/icon/yt_round2.png" alt=""></a>

                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                    </div>
                                    
                                    <div style="height:100px;"></div>
                                    <div class="clearfix"></div>