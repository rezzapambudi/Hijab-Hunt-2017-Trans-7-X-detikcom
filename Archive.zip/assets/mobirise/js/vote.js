<script>
    $(document).ready(function() {
  	$('#rootwizard').bootstrapWizard({'tabClass': 'nav nav-pills'});
});
</script>