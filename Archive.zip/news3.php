
    <section class="publicaciones-blog-home mbr-parallax-background" style="background-image: url(assets/images/bgnews.jpg);background-color: rgba(0, 0, 0, 0.73);">
      <div class="container">
        <div class="">
        <div class="wrap">
            

            <div class="type-wrap" style="border:none;">
                <div id="typed-strings">
                    <span>Berita <strong>Hijab Hunt</strong></span>
                    <span>Berita <strong>Hijab Hunt</strong></span>
                    <span>Berita <strong>Hijab Hunt</strong></span>
                    <span>Berita <strong>Hijab Hunt</strong></span>
                </div>
                <span id="typed" style="white-space:pre;"></span>
            </div>

            
        </div>
          <!--<h2 style="font-family: 'Reem Kufi', sans-serif;color:#35b51c;">Berita Hijab Hunt</h2>-->
          <div class="row-page row" style="font-family: 'Reem Kufi', sans-serif;padding-top: 76px;">
            <div class="col-page col-sm-8 col-md-6">
              <a href="" class="black fondo-publicacion-home">
                <div class="img-publicacion-principal-home">
                  <img class="undefined" src="" style="width: 300px;height: 400px;background-image: url(&quot;assets/images/iphone-6-458150-1920-1920x1285-73.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;">
                </div>
                <div class="contenido-publicacion-principal-home">
                  <h4 class="tbl">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h4>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed placerat porta ex, sed ullamcorper ipsum lacinia nec.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="col-page col-sm-4 col-md-3">
              <a href=""  class="fondo-publicacion-home">
                <div class="image"><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h4>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed placerat porta ex, sed ullamcorper ipsum lacinia nec.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="col-page col-sm-4 col-md-3">
              <a href="" class="fondo-publicacion-home">
                <div class="image"><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel4.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h4>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed placerat porta ex, sed ullamcorper ipsum lacinia nec.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="col-page col-sm-4 col-md-3">
              <a href="" class="fondo-publicacion-home">
                <div class="image"><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h4>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed placerat porta ex, sed ullamcorper ipsum lacinia nec.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="hidden-sm col-page col-sm-4 col-md-3">
              <a href="" class="fondo-publicacion-home">
                <div class="image"><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel4.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h4>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed placerat porta ex, sed ullamcorper ipsum lacinia nec.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="hidden-sm col-page col-sm-4 col-md-3">
              <a href="" class="fondo-publicacion-home">
                <div class="image"><img class="undefined" src="" style="width: 300px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                <div class="contenido-publicacion-home">
                  <h4 class="tbl">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h4>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed placerat porta ex, sed ullamcorper ipsum lacinia nec.<span>...</span></p>
                </div>
                <div class="mascara-enlace-blog-home">
                  <span>Selengkapnya</span>
                </div>
              </a>
            </div>
            <div class="col-page col-sm-4 col-md-3">
              <a href="#" class="todas-las-publicaciones-home">
                  <span>Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>