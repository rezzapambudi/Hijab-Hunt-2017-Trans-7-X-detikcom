<section class="mbr-section mbr-section--relative mbr-section--fixed-size mbr-parallax-background" id="form1-35" style="background-image: url(assets/images/bgdaftar.jpg);background-color: rgba(0, 0, 0, 0.73);">
    
    <div class="mbr-section__container mbr-section__container--std-padding container" id="daftar">
        <div class="row">
            <div class="col-sm-12">
                <div class="mbr-header mbr-header--center mbr-header--std-padding">
                            <h2 class="mbr-header__text" style="color:#f6f6f6;font-family: 'Reem Kufi', sans-serif;" >Registrasi</h2>
                        </div>
                <div class="row">
                    <div class="col-sm-6 " data-form-type="formoid">
                        
                        <div data-form-alert="true"></div>
                        <form action="#" method="post" data-form-title="CONTACT FORM">
                            <input type="hidden" value="" data-form-email="true">
                            <div class="form-group">
                                <input type="email" class="form-control" name="email" required="" placeholder="Email*" data-form-field="Email">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="name" required="" placeholder="Name*" data-form-field="Name">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="name" required="" placeholder="Nomor HP" data-form-field="Name">
                            </div>
                            
                            <div class="form-group">
                                <select class="form-control formz" placeholder="Jenis Kelamin" name="size">
                                    <option value="">Wanita</option>
                                    
                                </select>
                            </div>
                            <div class="form-group">
                                <select name="" placeholder="Tanggal lahir" id="" class="formz" style="width: 70px;">
                                    <option value=""></option>
                                </select>
                                <select name="" placeholder="Bulan lahir" id="" class="formz" style="width: 70px;">
                                    <option value=""></option>
                                </select>
                                <select name=""  id="" class="formz" style="width: 70px;">
                                    <option placeholder="Tahun lahir" value=""></option>
                                </select>
                            </div>
                            <div class="form-group">
                                <select name="" id="" placeholder="Domisili Provinsi" class="select select2 formz" style="width: 276px;">
                                    <option value=""> Pilih Provinsi</option>
                                    <option value=""> Aceh </option>
                                    <option value=""> Bali </option>
                                    <option value=""> Bangka Belitung </option>
                                </select>

                                <select name="" id="" placeholder="Domisili Kota" class="select select2 formz" style="width: 280px;">
                                    <option value=""> Pilih Kota</option>
                                    <option value=""> Bandung </option>
                                    <option value=""> Banjar </option>
                                    <option value=""> Bekasi </option>
                                    <option value=""> Bogor </option>
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="form-control formz" placeholder="Jenis Kelamin" name="size">
                                    <option value="">Status</option>
                                    
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="form-control formz" placeholder="Jenis Kelamin" name="size">
                                    <option value="">Pekerjaan</option>
                                    
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="form-control formz" placeholder="Jenis Kelamin" name="size">
                                    <option value="">Pendidikan Terakhir</option>
                                    
                                </select>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="name" required="" placeholder="Tinggi Badan" data-form-field="Name">
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" name="email" required="" placeholder="Berat Badan" data-form-field="Email">
                            </div>
                            <div class="form-group">
                                <label><h4 class="combostyle">Bakat</h4></label>
                                <div class="checkbox">
                                  <label class="combostyle"><input type="checkbox" value="" class="checkbox-circle">Menyanyi</label>
                                </div>
                                <div class="checkbox">
                                  <label class="combostyle"><input type="checkbox" value="">Menari</label>
                                </div>
                                <div class="checkbox disabled">
                                  <label class="combostyle"><input type="checkbox" value="" disabled>Akting</label>
                                </div>
                                <div class="checkbox">
                                  <label class="combostyle"><input type="checkbox" value="">Bermain Musik</label>
                                </div>
                                <div class="checkbox">
                                  <label class="combostyle"><input type="checkbox" value="">Bela Diri</label>
                                </div>
                                <div class="checkbox disabled">
                                  <label class="combostyle"><input type="checkbox" value="" disabled>Stand Up Comedy</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label><h4 class="combostyle">Foto Close Up *</h4></label>
                                <label><h4 class="combostyle" style="color:red;">* Max 200KB - jpg/jpeg </h4></label>
                                <input type="file" class="form-control" name="file" required="" placeholder="upload file" data-form-field="Email">
                            </div>
                            <div class="form-group">
                                <label><h4 class="combostyle">Foto Seluruh Badan *</h4></label>
                                <label><h4 class="combostyle" style="color:red;">* Max 200KB - jpg/jpeg </h4></label>
                                <input type="file" class="form-control" name="file" required="" placeholder="upload file" data-form-field="Email">
                            </div>
                            <div class="form-group">
                                <label><h4 class="combostyle">Foto Upload Produk *</h4></label>
                                <label><h4 class="combostyle" style="color:red;">* Max 200KB - jpg/jpeg </h4></label>
                                <input type="file" class="form-control" name="file" required="" placeholder="upload file" data-form-field="Email">
                            </div>
                        </form>
                    </div>
                    <div class="col-sm-6 " data-form-type="formoid">
                        
                        <div data-form-alert="true"></div>
                        <form action="#" method="post" data-form-title="CONTACT FORM">
                            <input type="hidden" value="" data-form-email="true">
                            
                            
                            
                            <div class="form-group">
                                <label><h4 class="combostyle">Sebutkan tiga (3) kata yang menggambarkan style hijabmu *</h4></label>
                                <input type="text" class="form-control" name="name" required="" placeholder="* Contoh: Ceria, Gaul, Modis" data-form-field="Name">
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" name="message" placeholder="Cerita pengalaman berhijab" rows="7" data-form-field="Message"></textarea>
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" name="message" placeholder="Prestasi (* min 100 karakter)" rows="7" data-form-field="Message"></textarea>
                            </div>
                            <div class="form-group">
                                <label><h4 class="combostyle">Pilih Lokasi Audisi Roadshow di kota terdekatmu: *</h4></label>
                                <div class="checkbox">
                                  <label class="combostyle"><input type="checkbox" value="" class="checkbox-circle">Makassar</label>
                                </div>
                                <div class="checkbox">
                                  <label class="combostyle"><input type="checkbox" value="">Medan</label>
                                </div>
                                <div class="checkbox disabled">
                                  <label class="combostyle"><input type="checkbox" value="" disabled>Surabaya</label>
                                </div>
                                <div class="checkbox">
                                  <label class="combostyle"><input type="checkbox" value="">Jakarta</label>
                                </div>
                                <div class="checkbox">
                                  <label class="combostyle"><input type="checkbox" value="">Bandung</label>
                                </div>
                                <div class="checkbox disabled">
                                  <label class="combostyle"><input type="checkbox" value="" disabled>Palembang</label>
                                </div>
                                <div class="checkbox disabled">
                                  <label class="combostyle"><input type="checkbox" value="" disabled>Banjarmasin</label>
                                </div>
                                <label><h4 class="combostyle" style="color:red;">Kamu sudah memilih lokasi Audisi, silahkan menghubungi Admin Sunsilk Hijab Hunt 2016 untuk perubahan jadwal</h4></label>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="name" required="" placeholder="Link Facebook, contoh: https://www.facebook.com/NAMAKAMU" data-form-field="Name">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="name" required="" placeholder="Link Instagram, contoh: https://www.instagram.com/NAMAKAMU" data-form-field="Name">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="name" required="" placeholder="Link Twitter, contoh: https://www.twitter.com/NAMAKAMU" data-form-field="Name">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="name" required="" placeholder="Lainnya" data-form-field="Name">
                            </div>
                            <div class="form-group">
                                <img src="assets/images/hero-recaptcha-demo.gif" class="img-responsive" style="max-width: 60%;">
                            </div>
                            <label><h4 class="combostyle">Dengan Mengirimkan Form Sunsilk Hijab Hunt 2016, Anda telah menyetujui Aturan, Syarat &amp; Ketentuan yang berlaku </h4></label>
                            <div class="mbr-buttons mbr-buttons--right"><button type="submit" class="mbr-buttons__btn btn btn-lg btn-warning">Kirim</button></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>