<section class="mbr-box mbr-section mbr-section--relative mbr-section--fixed-size mbr-section--full-height mbr-section--bg-adapted mbr-parallax-background" id="header1-43" style="background-image: url(assets/images/iphone-926663-1920-1920x1280-94.jpg);background-color: rgba(0, 0, 0, 0.4); */">
    <div class="mbr-box__magnet mbr-box__magnet--sm-padding mbr-box__magnet--center-left">
        <center><h3 class="mbr-hero__text wow lightSpeedIn" style="color:white;"></h3></center>
        <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(41, 43, 49);"></div>
        <div class="mbr-box__container mbr-section__container container">
            <div class="mbr-box mbr-box--stretched"><div class="mbr-box__magnet mbr-box__magnet--center-left">
                <div class="row"><div class=" col-sm-6">
                    <div class="mbr-hero wow fadeInUp">
                        <h1 class="mbr-hero__text"><img src="assets/images/logo_2016.png" class="img-responsive"></h1>
                        <p class="mbr-hero__subtext">Lorem Ipsum is simply dummy text of the printing and typesetting industry.<br></p>
                    </div>
                    <div class="mbr-buttons btn-inverse mbr-buttons--left"></div>
                </div></div>
            </div></div>
        </div>
        
    </div>
</section>


<section class="mbr-section mbr-section--relative mbr-parallax-background" id="msg-box5-46" style="background-image: url(assets/images/bgabout.jpg);">
    <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(71, 91, 105);"></div>
    <div class="mbr-section__container mbr-section__container--isolated container">
        <div class="row" style="padding-top: 14px;padding-bottom: 14px;border-radius:5px;">
            <div class="mbr-box mbr-box--fixed mbr-box--adapted">
                <div class="mbr-box__magnet mbr-box__magnet--top-right mbr-section__left col-sm-6 wow fadeInLeft">
                    <figure class="mbr-figure mbr-figure--adapted mbr-figure--caption-inside-bottom mbr-figure--full-width"><img class="mbr-figure__img" src="assets/images/imac-605421-1920-1920x1275-41.jpg"></figure>
                </div>
                <div class="mbr-box__magnet mbr-class-mbr-box__magnet--center-left col-sm-6 mbr-section__right wow fadeInRight">
                    <div class="mbr-section__container mbr-section__container--middle">
                        <div class="mbr-header mbr-header--auto-align mbr-header--wysiwyg">
                            <div class="wrap" style="font-size:18px !important;">
                                <div class="type-wrap">
                                    <div id="typed-strings">
                                        <span>Hijab Hunt 2017 Akan Segera Dimulai</span>
                                        <span>Daftarkan Dirimu <strong>Segera</strong></span>
                                        <span>Isi Form Registrasi Di Microsite</span>
                                        <span>Setelah Daftar Data Kamu Akan Dimoderasi</span>
                                        <span>Tunggu Hingga Pengumuman Selanjutnya</span>
                                    </div>
                                    <span id="typed" style="white-space:pre;"></span>
                                </div>
                            </div>
                            <!--<h3 class="mbr-header__text">Hijab Hunt 2017 Akan Segera Dimulai, Daftarkan Dirimu Segera</h3>-->
                            
                        </div>
                    </div>
                    <div class="mbr-section__container mbr-section__container--middle">
                        <div class="mbr-article mbr-article--auto-align mbr-article--wysiwyg"><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></div>
                    </div>
                    <div class="mbr-section__container">
                        <div class="mbr-buttons mbr-buttons--auto-align btn-inverse"></div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>