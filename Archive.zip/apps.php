<section class="pricing-table-1 col-2" id="pricing-table1-53" style="background-color: rgb(240, 240, 240);">
    

    <div class="container">
        <div class="row">
            <div>
                <div class="plan green wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="300ms">
                    <h3>FAMILY TOURING</h3>
                    <p class="price">
                        <img src="assets/images/holidays.png">
                    </p>
                    <div><ul><li><strong>Family Touring merupakan .... </strong> </li></ul></div>
                    <p><a href="#" class="btn btn-success">DAFTAR</a></p>
                </div>
            </div>
            <div>
                <div class="plan orange wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="900ms">
                    <h3>COACHING CLINIC</h3>
                    <p class="price">
                        <img src="assets/images/racing.png">
                    </p>
                    <div><ul><li><strong>Coaching Clinic merupakan .... </strong> </li></ul></div>
                    <p><a href="#" class="btn btn-success">DAFTAR</a></p>
                </div>
            </div>
            
        </div>
    </div>
</section>