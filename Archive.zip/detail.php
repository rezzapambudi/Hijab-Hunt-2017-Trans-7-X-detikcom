<!DOCTYPE html>
<html>
<head>
  <!-- Mobirise Free Bootstrap Template, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v2.6.1, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="assets/images/discover-mobile-350x350-16.png" type="image/x-icon">
  <meta name="description" content="video background">
  <title>NISSAN | X-TRAIL</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:700,400&amp;subset=cyrillic,latin,greek,vietnamese">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/animate.css/animate.min.css">
  <link rel="stylesheet" href="assets/socicon/css/socicon.min.css">
  <link rel="stylesheet" href="assets/mobirise/css/style.css">
  <link rel="stylesheet" href="assets/mobirise-slider/style.css">
  <link rel="stylesheet" href="assets/mobirise-gallery/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
</head>
<body>
<section class="mbr-navbar mbr-navbar--freeze mbr-navbar--absolute mbr-navbar--transparent mbr-navbar--sticky mbr-navbar--auto-collapse" id="menu-41">
    <div class="mbr-navbar__section mbr-section" style="background:#2c2c2c;">
        <div class="mbr-section__container container">
            <div class="mbr-navbar__container">
                <div class="mbr-navbar__column mbr-navbar__column--s mbr-navbar__brand">
                    <span class="mbr-navbar__brand-link mbr-brand mbr-brand--inline">
                        <span class="mbr-brand__logo"><a href="https://mobirise.com/bootstrap-template/"><img class="mbr-navbar__brand-img mbr-brand__img" src="assets/images/discover-mobile-350x350-53.png" alt="Mobirise"></a></span>
                        <span class="mbr-brand__name"><a class="mbr-brand__name text-white" href="#">X-TRAIL</a></span>
                    </span>
                </div>
                <div class="mbr-navbar__hamburger mbr-hamburger text-white"><span class="mbr-hamburger__line"></span></div>
                <div class="mbr-navbar__column mbr-navbar__menu">
                    <nav class="mbr-navbar__menu-box mbr-navbar__menu-box--inline-right">
                        <div class="mbr-navbar__column"><ul class="mbr-navbar__items mbr-navbar__items--right mbr-buttons mbr-buttons--freeze mbr-buttons--right btn-decorator mbr-buttons--active"><li class="mbr-navbar__item"><a class="mbr-buttons__link btn text-white" href="index.php#header1-40">HOME</a></li> <li class="mbr-navbar__item"><a class="mbr-buttons__link btn text-white" href="#features1-42">NEWS</a></li><li class="mbr-navbar__item"><a class="mbr-buttons__link btn text-white" href="index.php#msg-box3-48">WEB SERIES</a></li> <li class="mbr-navbar__item"><a class="mbr-buttons__link btn text-white" href="index.php#header1-43">ABOUT AS</a></li></ul></div>
                        <div class="mbr-navbar__column"><ul class="mbr-navbar__items mbr-navbar__items--right mbr-buttons mbr-buttons--freeze mbr-buttons--right btn-inverse mbr-buttons--active"><li class="mbr-navbar__item"></li></ul></div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>

<a href="detail.html" style="cursor:pointer;">
    <section class="listatas" id="features1-42">
        <div class="container">
       
          <div>
            <center>
            <div class="col-md-4 col-sm-12">
                <img src="" alt="" style="width: 300px;height: 270px;background-image: url(&quot;assets/images/google-slides-350x350-16.png&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;">
            </div>
            </center>
            <div class="col-md-8 col-sm-12" style="padding-left: 10px;padding-right: 10px;">
            
            <h3 style="padding-bottom: 15px;">
            ALL-NEW NISSAN X-TRAIL
            </h3>
            
              <p>
                Jika Anda memiliki jiwa petualang, All New Nissan X-Trail adalah kendaraan yang tepat untuk memenuhi insting petualang Anda. Menemani Anda ke mana saja dengan tampilan dan kenyamanan berkelas serta teknologi yang memberi kemudahan. 
              </p>
            </div>
          </div>
        </div>
      </section>
</a>
<a href="detail.html" style="cursor:pointer;">
    <section class="list2" id="features1-42">
        <div class="container">
       
          <div>
            <center>
            <div class="col-md-4 col-sm-12">
                <img src="" alt="" style="width: 300px;height: 270px;background-image: url(&quot;assets/images/google-slides-350x350-16.png&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;">
            </div>
            </center>
            <div class="col-md-8 col-sm-12" style="padding-left: 10px;padding-right: 10px;">
            
            <h3 style="padding-bottom: 15px;">
            ALL-NEW NISSAN X-TRAIL
            </h3>
            
              <p>
                Jika Anda memiliki jiwa petualang, All New Nissan X-Trail adalah kendaraan yang tepat untuk memenuhi insting petualang Anda. Menemani Anda ke mana saja dengan tampilan dan kenyamanan berkelas serta teknologi yang memberi kemudahan. 
              </p>
            </div>
          </div>
        </div>
      </section>
</a>
<a href="detail.html" style="cursor:pointer;">
    <section class="list1" id="features1-42">
        <div class="container">
       
          <div>
            <center>
            <div class="col-md-4 col-sm-12">
                <img src="" alt="" style="width: 300px;height: 270px;background-image: url(&quot;assets/images/google-slides-350x350-16.png&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;">
            </div>
            </center>
            <div class="col-md-8 col-sm-12" style="padding-left: 10px;padding-right: 10px;">
            
            <h3 style="padding-bottom: 15px;">
            ALL-NEW NISSAN X-TRAIL
            </h3>
            
              <p>
                Jika Anda memiliki jiwa petualang, All New Nissan X-Trail adalah kendaraan yang tepat untuk memenuhi insting petualang Anda. Menemani Anda ke mana saja dengan tampilan dan kenyamanan berkelas serta teknologi yang memberi kemudahan. 
              </p>
            </div>
          </div>
        </div>
      </section>
</a>
<a href="detail.html" style="cursor:pointer;">
    <section class="list2" id="features1-42">
        <div class="container">
       
          <div>
            <center>
            <div class="col-md-4 col-sm-12">
                <img src="" alt="" style="width: 300px;height: 270px;background-image: url(&quot;assets/images/google-slides-350x350-16.png&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;">
            </div>
            </center>
            <div class="col-md-8 col-sm-12" style="padding-left: 10px;padding-right: 10px;">
            
            <h3 style="padding-bottom: 15px;">
            ALL-NEW NISSAN X-TRAIL
            </h3>
            
              <p>
                Jika Anda memiliki jiwa petualang, All New Nissan X-Trail adalah kendaraan yang tepat untuk memenuhi insting petualang Anda. Menemani Anda ke mana saja dengan tampilan dan kenyamanan berkelas serta teknologi yang memberi kemudahan. 
              </p>
            </div>
          </div>
        </div>
      </section>
</a>

<?php include "footer.php";?>

  <script src="assets/jquery/jquery.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js"></script>
  <script src="assets/smooth-scroll/SmoothScroll.js"></script>
  <script src="assets/jquery-mb-ytplayer/jquery.mb.YTPlayer.min.js"></script>
  <script src="assets/jarallax/jarallax.js"></script>
  <script src="assets/bootstrap-carousel-swipe/bootstrap-carousel-swipe.js"></script>
  <script src="assets/masonry/masonry.pkgd.min.js"></script>
  <script src="assets/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/social-likes/social-likes.js"></script>
  <script src="assets/mobirise/js/script.js"></script>
  <script src="assets/mobirise-gallery/script.js"></script>
  
  
</body>
</html>