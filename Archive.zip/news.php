<section class="content-2 col-4 mbr-parallax-background" id="features1-42" style="background-image: url(assets/images/bgnews.jpg);padding-bottom:20px;">
    <div class="container">
        <center><h3 class="mbr-header__text wow lightSpeedIn" style="padding-bottom: 30px;font-family: 'Reem Kufi', sans-serif;">NEWS</h3></center>
        <div class="row">
            <div class="boxarticle">
                <div class="thumbnail thumb-shadow">
                    <div class="image"><img class="undefined" src="" style="width: 400px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                    <div class="caption">
                        <div>
                            <a href="#"><h3 class="judul">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h3></a>
                            <p class="artikel">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita. Lorem ipsum dolor sit amet, consectetur adipiscing elit.&nbsp;</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="boxarticle">
                <div class="thumbnail thumb-shadow">
                    <div class="image"><img class="undefined" src="" style="width: 400px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel4.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                    <div class="caption">
                        <div>
                            <a href="#"><h3 class="judul">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h3></a>
                            <p class="artikel">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita. Lorem ipsum dolor sit amet, consectetur adipiscing elit.&nbsp;</p>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="boxarticle">
                <div class="thumbnail thumb-shadow">
                    <div class="image"><img class="undefined" src="" style="width: 400px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel1.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                    <div class="caption">
                        <div>
                            <a href="#"><h3 class="judul">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h3></a>
                            <p class="artikel">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita. Lorem ipsum dolor sit amet, consectetur adipiscing elit.&nbsp;</p>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="boxarticle">
                <div class="thumbnail thumb-shadow">
                    <div class="image"><img class="undefined" src="" style="width: 400px;height: 195px;background-image: url(&quot;assets/images/article/img_artikel4.jpg&quot;);background-size: cover;background-repeat: no-repeat;background-position: 50% 50%;"></div>
                    <div class="caption">
                        <div>
                            <a href="#"><h3 class="judul">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita</h3></a>
                            <p class="artikel">Tutorial Hijab dengan Scarf Panjang ala Si Cantik Nada Puspita. Lorem ipsum dolor sit amet, consectetur adipiscing elit.&nbsp;</p>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <center>
<section class="content-1 col-1 wow zoomIn" id="features1-42" style="background-color: rgba(255, 255, 255, 0);padding-bottom:30px;padding-top: 25px;">
    <a href="audisi.php"><img src="assets/images/load-more.png"></a>
</section>
</center>
</section>
